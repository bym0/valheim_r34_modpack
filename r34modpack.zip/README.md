# r34_modpack

just a little modpack for me and my friends, this modpack itself holds no files. i just add the mods as dependencies.